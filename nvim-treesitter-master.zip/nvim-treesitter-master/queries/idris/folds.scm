(function) @fold
