(word_definition) @fold
