[
  (record)
  (module)
] @fold
