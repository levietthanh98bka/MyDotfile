(reduction) @fold
