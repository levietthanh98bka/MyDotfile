(entry) @fold
