[
  (object)
  (array)
] @fold
