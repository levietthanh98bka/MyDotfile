(document) @indent.auto
